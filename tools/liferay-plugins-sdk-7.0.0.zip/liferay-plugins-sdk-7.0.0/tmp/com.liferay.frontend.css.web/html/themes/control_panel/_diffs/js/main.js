Liferay.Util.portletTitleEdit = function() {
};